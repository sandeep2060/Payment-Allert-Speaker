package com.newline.paymentspeaker.detection

import java.util.Locale

data class ParsedPayment(
    val provider: String,
    val amount: Double,
    val reference: String?,
    val title: String,
    val message: String
)

object PaymentParser {
    // Package-name allowlist. Populate with verified package IDs from your installed apps.
    // Never identify a provider from message text alone.
    private val packageProviders = mapOf(
        // "verified.esewa.package" to "eSewa",
        // "verified.khalti.package" to "Khalti",
        // "verified.fonepay.package" to "Fonepay",
        // "verified.bank.app.package" to "Bank"
    )

    private val amountPatterns = listOf(
        Regex("""(?i)(?:NPR|Rs\.?|रु\.?|रू\.?)\s*([0-9][0-9,]*(?:\.\d{1,2})?)"""),
        Regex("""(?i)([0-9][0-9,]*(?:\.\d{1,2})?)\s*(?:NPR|रु\.?|रू\.?)""")
    )
    private val negative = listOf(
        "failed", "failure", "pending", "rejected", "cancelled", "canceled",
        "reversed", "refund", "refunded", "unsuccessful", "debited", "withdrawn",
        "असफल", "रद्द", "फिर्ता", "डेबिट", "निकालिएको"
    )
    private val positive = listOf(
        "received", "successful", "success", "credited", "payment received",
        "amount received", "deposit", "जम्मा भयो", "प्राप्त भयो", "आएको छ"
    )

    fun parse(packageName: String, title: String, message: String): ParsedPayment? {
        val provider = packageProviders[packageName] ?: return null
        val combined = "$title $message"
        val normalized = combined.lowercase(Locale.ROOT)
        if (negative.any { normalized.contains(it) }) return null
        if (positive.none { normalized.contains(it) }) return null

        val amountText = amountPatterns.firstNotNullOfOrNull { regex ->
            regex.find(combined)?.groupValues?.get(1)
        } ?: return null

        val amount = amountText.replace(",", "").toDoubleOrNull() ?: return null
        if (!amount.isFinite() || amount <= 0.0) return null

        val refRegex = Regex(
            """(?i)(?:transaction|txn|reference|ref|trace)\s*(?:id|no|number)?\s*[:#-]?\s*([A-Z0-9-]{5,})"""
        )
        val reference = refRegex.find(combined)?.groupValues?.get(1)
        return ParsedPayment(provider, amount, reference, title, message)
    }

    fun supportedPackages(): Map<String, String> = packageProviders
}

package com.newline.paymentspeaker.speaker

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class SpeechManager(context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    @Volatile private var ready = false
    @Volatile private var preferredLanguage = "BOTH"

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
    }

    fun setLanguage(language: String) { preferredLanguage = language }

    fun speak(amount: Double, provider: String) {
        if (!ready) return
        val formatted = String.format(Locale.US, "%,.2f", amount)
        val nepali = preferredLanguage == "NEPALI"
        val locale = if (nepali) Locale("ne", "NP") else Locale.US
        val result = tts?.setLanguage(locale) ?: TextToSpeech.LANG_MISSING_DATA
        val text = if (nepali && result >= TextToSpeech.LANG_AVAILABLE) {
            "$provider बाट रु $formatted भुक्तानी आएको सूचना प्राप्त भयो। कृपया खातामा पुष्टि गर्नुहोस्।"
        } else {
            "Payment notification. Rupees $formatted reported by $provider. Please verify in your bank or wallet."
        }
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "payment-${System.nanoTime()}")
    }

    fun stop() { tts?.stop() }
    fun close() { tts?.stop(); tts?.shutdown(); tts = null; ready = false }
}

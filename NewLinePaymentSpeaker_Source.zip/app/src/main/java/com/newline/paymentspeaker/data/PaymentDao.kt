package com.newline.paymentspeaker.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(item: PaymentEntity): Long

    @Query("SELECT * FROM payments ORDER BY receivedAt DESC")
    fun observeAll(): Flow<List<PaymentEntity>>

    @Query("UPDATE payments SET spoken = :spoken WHERE fingerprint = :id")
    suspend fun markSpoken(id: String, spoken: Boolean)

    @Query("DELETE FROM payments")
    suspend fun clear()
}

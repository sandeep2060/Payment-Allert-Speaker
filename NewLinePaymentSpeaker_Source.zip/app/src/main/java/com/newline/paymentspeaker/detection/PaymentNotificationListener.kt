package com.newline.paymentspeaker.detection

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.newline.paymentspeaker.data.AppDatabase
import com.newline.paymentspeaker.data.PaymentEntity
import com.newline.paymentspeaker.speaker.SpeechManager
import kotlinx.coroutines.*
import java.security.MessageDigest

class PaymentNotificationListener : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var db: AppDatabase
    private lateinit var speech: SpeechManager

    override fun onListenerConnected() {
        super.onListenerConnected()
        db = AppDatabase.get(this)
        speech = SpeechManager(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!::db.isInitialized || sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val textParts = mutableListOf<String>()
        extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.let(textParts::add)
        extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.let(textParts::add)
        extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.forEach {
            textParts.add(it.toString())
        }
        val message = textParts.distinct().joinToString(" ").take(1000)
        if (title.isBlank() || message.isBlank()) return
        val parsed = PaymentParser.parse(sbn.packageName, title, message) ?: return
        val fingerprint = sha256(
            "${sbn.packageName}|${parsed.reference ?: sbn.key}|${parsed.amount}"
        )
        scope.launch {
            val row = PaymentEntity(
                fingerprint = fingerprint,
                provider = parsed.provider,
                amount = parsed.amount,
                reference = parsed.reference,
                title = title.take(200),
                message = message.take(500),
                receivedAt = System.currentTimeMillis()
            )
            val inserted = db.payments().insert(row)
            if (inserted != -1L) {
                withContext(Dispatchers.Main) { speech.speak(parsed.amount, parsed.provider) }
                db.payments().markSpoken(fingerprint, true)
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        if (::speech.isInitialized) speech.close()
        super.onDestroy()
    }

    private fun sha256(value: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray())
            .joinToString("") { "%02x".format(it) }
}

package com.newline.paymentspeaker

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.newline.paymentspeaker.data.AppDatabase
import com.newline.paymentspeaker.data.PaymentEntity
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PaymentSpeakerApp() }
    }
}

@Composable
fun PaymentSpeakerApp() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.get(context).payments() }
    val payments by dao.observeAll().collectAsState(initial = emptyList())
    var listenerEnabled by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf("BOTH") }

    LaunchedEffect(Unit) {
        while (true) {
            listenerEnabled = Settings.Secure.getString(
                context.contentResolver, "enabled_notification_listeners"
            )?.contains(context.packageName) == true
            delay(1500)
        }
    }

    val todayStart = remember {
        val c = java.util.Calendar.getInstance()
        c.set(java.util.Calendar.HOUR_OF_DAY, 0)
        c.set(java.util.Calendar.MINUTE, 0)
        c.set(java.util.Calendar.SECOND, 0)
        c.set(java.util.Calendar.MILLISECOND, 0)
        c.timeInMillis
    }
    val today = payments.filter { it.receivedAt >= todayStart }
    val total = today.sumOf { it.amount }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFFB7FF00),
            background = androidx.compose.ui.graphics.Color(0xFF0B0B0B),
            surface = androidx.compose.ui.graphics.Color(0xFF171717)
        )
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("NEWLINE", style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary)
                    Text("Payment Speaker", style = MaterialTheme.typography.headlineMedium)
                    Text("Local notification-based payment alerts",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                item {
                    ElevatedCard {
                        Column(Modifier.padding(18.dp)) {
                            Text("Today's detected payment notifications")
                            Text("NPR ${"%,.2f".format(total)}",
                                style = MaterialTheme.typography.headlineLarge,
                                color = MaterialTheme.colorScheme.primary)
                            Text("${today.size} detected events")
                        }
                    }
                }
                item {
                    Text(
                        if (listenerEnabled) "● Notification access enabled"
                        else "● Notification access required",
                        color = if (listenerEnabled) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.error
                    )
                    Button(
                        onClick = {
                            context.startActivity(
                                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Open notification access settings") }
                }
                item {
                    Text("Announcement language", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("NEPALI" to "नेपाली", "ENGLISH" to "English",
                            "BOTH" to "Both").forEach { (value, label) ->
                            FilterChip(
                                selected = language == value,
                                onClick = { language = value },
                                label = { Text(label) }
                            )
                        }
                    }
                    Text("Language selection is saved for this screen in this starter build.",
                        style = MaterialTheme.typography.bodySmall)
                }
                item { Text("Recent notifications", style = MaterialTheme.typography.titleLarge) }
                if (payments.isEmpty()) {
                    item { Text("No payment notifications detected yet.") }
                } else {
                    items(payments.take(100), key = { it.fingerprint }) { payment ->
                        PaymentRow(payment)
                    }
                }
                item {
                    OutlinedButton(
                        onClick = { /* Test speech can be added after selecting a TTS voice. */ },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Test speaker — configure in next build") }
                }
                item {
                    Text(
                        "Safety: notifications are not bank-verified. Always check the official wallet or bank app before handing over goods.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
private fun PaymentRow(payment: PaymentEntity) {
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(payment.provider, style = MaterialTheme.typography.titleMedium)
                Text("NPR ${"%,.2f".format(payment.amount)}",
                    color = MaterialTheme.colorScheme.primary)
            }
            Text(SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                .format(Date(payment.receivedAt)),
                style = MaterialTheme.typography.bodySmall)
            Text("Notification detected · Not independently verified",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error)
        }
    }
}

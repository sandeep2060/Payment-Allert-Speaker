package com.newline.paymentspeaker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey val fingerprint: String,
    val provider: String,
    val amount: Double,
    val currency: String = "NPR",
    val reference: String?,
    val title: String,
    val message: String,
    val receivedAt: Long,
    val status: String = "NOTIFICATION_DETECTED",
    val spoken: Boolean = false
)

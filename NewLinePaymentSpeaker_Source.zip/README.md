# NewLine Payment Speaker

Android Kotlin starter project for a single-shop notification-based payment speaker.

## Scope
- Android app, local Room database, notification listener, Text-to-Speech.
- Intended provider categories: eSewa, Khalti, Fonepay and supported bank apps.
- Nepali and English voice support depends on the TTS voice installed on the phone.
- Phone and Bluetooth output use Android's active audio route.

## Critical setup before real testing
1. Install eSewa, Khalti, Fonepay and the bank apps you want to monitor.
2. Obtain their actual Android package IDs from the device.
3. Add only verified package IDs to `PaymentParser.packageProviders`.
4. Capture sample successful, pending, failed, debit, refund and reversal notifications.
5. Replace the generic parser with provider-specific parsing rules tested against those samples.
6. Test on each target device and Android version.

## Important limitations
This project does NOT verify transactions with banks or payment providers. It reads notifications only. Notification content may be hidden, delayed, spoofed, changed or unavailable. Never use a voice announcement as proof of settlement. Verify payments in the official provider app/bank account before releasing goods.

The current code is a development starter, not a certified or production-tested APK. The package allowlist is intentionally empty so the app does not guess provider identities or parse unrelated notifications.

## Build
Open this folder in Android Studio with a compatible JDK (17), Android SDK and Gradle. Sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

## Privacy
The app stores captured matching notification details locally in Room. Before production, provide a clear privacy notice, data-retention controls and tested deletion/export behavior. Do not collect OTPs or unrelated notifications.
